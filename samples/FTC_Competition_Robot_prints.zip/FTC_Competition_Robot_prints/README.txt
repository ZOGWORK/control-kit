Assembly: FTC Competition Robot
Scan date: 2026-10-23T12:00:00.000Z
Zip date: 2026-10-23T12:00:00.000Z

STL files and source links:
FTC_Competition_Robot_prints/intake/custom_printed_intake_guide__intakegu.stl
  https://cad.onshape.com/documents/robot/w/fixture/e/prints

FAILED parts:
5203 Motor: STL translation request failed (HTTP 404)
  https://cad.onshape.com/documents/robot/w/fixture/e/motors